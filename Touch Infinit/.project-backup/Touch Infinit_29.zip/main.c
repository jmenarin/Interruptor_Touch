#include <atmel_start.h>
#include <touch_example.h>
#include <util/delay.h>


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		//touch_example();
		/*if(SINAL_RELE1_get_level(1)){
			LED1_set_level(1);
		}else{
			LED1_set_level(0);
		}
		if(SINAL_RELE2_get_level(1)){
			LED2_set_level(1);
			}else{
			LED2_set_level(0);
		}
		if(SINAL_RELE3_get_level(1)){
			LED3_set_level(1);
			}else{
			LED3_set_level(0);
		}*/
		BUTTON_MOD1_set_level(0);
		
		
	}
}
